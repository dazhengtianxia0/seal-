#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "emit.h"
#include "seal-decl.h"
#include "seal-stmt.h"
#include "seal-expr.h"
#include "symtab.h"
#include <map>
#include <string>
#include "list.h"

#define TRUE 1
#define FALSE 0